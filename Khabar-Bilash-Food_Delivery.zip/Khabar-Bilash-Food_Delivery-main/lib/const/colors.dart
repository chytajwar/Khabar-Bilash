import 'package:flutter/material.dart';

const Color BackgroundColor = Color.fromARGB(255, 38, 34, 44);
const Color RrestaurantAppBarColor = Colors.black26;
const Color PositionedContainerrColor = Colors.white70;
const Color ItemContainerrColor = Colors.white60;

//============================================
const Color PrimaryTextColor = Colors.white;
const Color SecondaryTextColor = Colors.white70;

const Color ButtonColor = Colors.black12;

const Color AddButtonColor = Colors.black;

const Color RatingColor = Colors.yellow;

//============================================

